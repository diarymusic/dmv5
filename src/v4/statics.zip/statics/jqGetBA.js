

window.onload = function(){
    $.ajax({
    type: "GET",
    // url: "https://www.beatarray.com/api/submit/labelAuditGetSubmits?page=1&pageSize=1000&sortKey=createdTime&sortMethod=-1&labelId=263",
    url:"test.json",
    headers: {
        Token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTc0MywiaWF0IjoxNjkyMTk1MTk5LCJleHAiOjE2OTQ3ODcxOTl9.2j2ZUxGs90-gZGX1Vwp3eDwZxqBV8NkcWLOpvDZ_B78" ,
    },
    success: function(result) {
        
        var total = result['data']['total'];
        var list = result['data']['list'];

        for (let index = 0; index < list.length; index++) {
            // var ix = str.indexOf(list[]);
            // if(ix=="-1" | ix=="2"){//大于0 代表存在，
            // str.splice(ix,1);//存在就删除
            // }

            
            var title = list[index]['title'];
            var genre = list[index]['genre'];
            var type = list[index]['type'];
            var author = list[index]['author'];
            var link = list[index]['link'];
            var code = list[index]['code'];
            var status = list[index]['status'];
            var disable = ''
            if(status == -1){
                state = '未过审'
                disable = 'disabled'
            }else if(status == 0){
                state = '待审核'
            }else if(status == 1){
                state = '待复审'
            }else if(status == 2){
                state = '已过审'
                disable = 'disabled'
            }
            var date = list[index]['updatedTime'];

            var l = $(
'<div class="activity-data">'
                    
                    
                +'<div class="data names"><span class="data-title">作品名称</span><span class="data-list">'
                +title
                +'</span></div>'
                +'<div class="data names"><span class="data-title">艺人艺名</span><span class="data-list">'
                +author
                +'</span></div>'
                +'<div class="data names d-sm-none"><span class="data-title">投稿日期</span><span class="data-list">'
                +date
                +'</span></div>'
                +'<div class="data names"><span class="data-title">稿件状态</span><span class="data-list">'
                +state
                +'</span></div>'
                +'<button class="btn btn-primary audit" data-bs-toggle="modal" data-bs-target="#auditmode"'
                +disable
                +'data-snm="'
                +title
                +'"'
                +'data-gnr="'
                +genre
                +'"'
                +'data-typ="'
                +type
                +'"'
                +'data-cod="'
                +code
                +'"'
                +'data-lnk="'
                +link
                +'"'
                +'>审核</button>'
+'</div>'
        )
        l.appendTo('.activity-list')
        }
            

       
       /*
        0 未审核
        -1 未过审
        1 过初审/需要复审
        2 过复审
        */
       /*
                    <div class="data names">
                        <span class="data-title">作品名称</span>
                        <span class="data-list">Firefly</span>
                    </div>
                    <div class="data email">
                        <span class="data-title">艺人艺名</span>
                        <span class="data-list">Hut</span>
                    </div>
                    <div class="data joined">
                        <span class="data-title">投稿日期</span>
                        <span class="data-list">2023-8-4</span>
                    </div>
                    <div class="data type">
                        <span class="data-title">稿件信息</span>
                        <span class="data-list">二次投稿</span>
                    </div>
                    <div class="data status">
                        <span class="data-title">稿件状态</span>
                        <span class="data-list">待审核</span>
                    </div>
                </div>
       */
       
    }
});
}
